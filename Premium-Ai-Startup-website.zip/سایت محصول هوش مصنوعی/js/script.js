(() => {
  'use strict';

  const root = document.documentElement;
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------------------
     Theme toggle (light / dark) with persistence
  --------------------------------------------------------- */
  const themeToggle = document.getElementById('themeToggle');
  const THEME_KEY = 'afarin-theme';

  function applyTheme(theme){
    if (theme === 'dark' || theme === 'light') {
      root.setAttribute('data-theme', theme);
    } else {
      root.removeAttribute('data-theme');
    }
  }

  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme) applyTheme(savedTheme);

  themeToggle?.addEventListener('click', () => {
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const current = root.getAttribute('data-theme') || (systemDark ? 'dark' : 'light');
    const next = current === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem(THEME_KEY, next);
  });

  /* ---------------------------------------------------------
     Header scroll state
  --------------------------------------------------------- */
  const header = document.getElementById('siteHeader');
  const headerCta = document.getElementById('headerCta');
  function onScroll(){
    const scrolled = window.scrollY > 24;
    header?.classList.toggle('is-scrolled', scrolled);
    if (headerCta) headerCta.style.display = scrolled ? 'inline-flex' : 'none';
  }
  document.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------------------------------------------------------
     Mobile nav drawer
  --------------------------------------------------------- */
  const menuToggle = document.getElementById('menuToggle');
  const mobileNav = document.getElementById('mobile-nav');

  function closeMobileNav(){
    menuToggle?.classList.remove('is-open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    mobileNav?.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  menuToggle?.addEventListener('click', () => {
    const isOpen = mobileNav?.classList.toggle('is-open');
    menuToggle.classList.toggle('is-open', !!isOpen);
    menuToggle.setAttribute('aria-expanded', String(!!isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  mobileNav?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', closeMobileNav);
  });

  /* ---------------------------------------------------------
     One orchestrated hero entrance
  --------------------------------------------------------- */
  window.addEventListener('DOMContentLoaded', () => {
    const heroEls = document.querySelectorAll('[data-reveal-group="hero"]');
    heroEls.forEach((el, i) => {
      if (prefersReducedMotion){
        el.classList.add('is-visible');
        return;
      }
      setTimeout(() => el.classList.add('is-visible'), 120 + i * 160);
    });
  });

  /* ---------------------------------------------------------
     Stat counters (used inside the "by the numbers" band)
  --------------------------------------------------------- */
  function animateCount(el){
    if (!el || el.dataset.counted) return;
    el.dataset.counted = '1';
    const target = parseFloat(el.getAttribute('data-target'));
    const suffix = el.getAttribute('data-suffix') || '';
    const isDecimal = String(el.getAttribute('data-target')).includes('.');

    if (prefersReducedMotion || Number.isNaN(target)){
      el.textContent = (Number.isNaN(target) ? el.getAttribute('data-target') : (isDecimal ? target.toFixed(1) : Math.round(target))) + suffix;
      return;
    }

    const duration = 1400;
    const startTime = performance.now();
    function tick(now){
      const progress = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = target * eased;
      el.textContent = (isDecimal ? value.toFixed(1) : Math.round(value)) + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ---------------------------------------------------------
     Scroll reveal — fades/slides content in as it enters view
     (direction comes from .reveal-left / .reveal-right; plain
     .reveal fades upward). Also triggers stat counters.
  --------------------------------------------------------- */
  const revealTargets = document.querySelectorAll('.reveal:not([data-reveal-group="hero"])');
  if ('IntersectionObserver' in window && !prefersReducedMotion){
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('is-visible');
          const counter = entry.target.querySelector('.js-count');
          if (counter) animateCount(counter);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    revealTargets.forEach(el => io.observe(el));
  } else {
    revealTargets.forEach(el => {
      el.classList.add('is-visible');
      const counter = el.querySelector('.js-count');
      if (counter) animateCount(counter);
    });
  }

  /* ---------------------------------------------------------
     Product showcase tabs
  --------------------------------------------------------- */
  const tabs = document.querySelectorAll('.showcase-tab');
  const panels = document.querySelectorAll('.showcase-panel');

  function activateShowcaseTab(targetId){
    tabs.forEach(t => t.setAttribute('aria-selected', String(t.getAttribute('data-target') === targetId)));
    panels.forEach(panel => panel.classList.toggle('is-active', panel.id === targetId));
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => activateShowcaseTab(tab.getAttribute('data-target')));
  });

  /* Links inside the header dropdown / mobile menu that jump straight to a tab */
  document.querySelectorAll('[data-tab-target]').forEach(link => {
    link.addEventListener('click', () => activateShowcaseTab(link.getAttribute('data-tab-target')));
  });

  /* ---------------------------------------------------------
     Desktop dropdown menus (محصول / ویژگی‌ها / منابع)
  --------------------------------------------------------- */
  const navItems = document.querySelectorAll('.nav-item.has-dropdown');

  function closeAllDropdowns(except){
    navItems.forEach(item => {
      if (item !== except){
        item.classList.remove('is-open');
        item.querySelector('.nav-link')?.setAttribute('aria-expanded', 'false');
      }
    });
  }

  navItems.forEach(item => {
    const trigger = item.querySelector('.nav-link');
    trigger?.addEventListener('click', (e) => {
      e.stopPropagation();
      const willOpen = !item.classList.contains('is-open');
      closeAllDropdowns(item);
      item.classList.toggle('is-open', willOpen);
      trigger.setAttribute('aria-expanded', String(willOpen));
    });
  });

  document.addEventListener('click', () => closeAllDropdowns(null));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAllDropdowns(null);
  });

  /* ---------------------------------------------------------
     Mobile nav — collapsible groups (محصول / ویژگی‌ها)
  --------------------------------------------------------- */
  document.querySelectorAll('.mnav-group').forEach(group => {
    const toggle = group.querySelector('.mnav-toggle');
    const panel = group.querySelector('.mnav-panel');
    if (!toggle || !panel) return;

    toggle.addEventListener('click', () => {
      const willOpen = !group.classList.contains('is-open');
      group.classList.toggle('is-open', willOpen);
      toggle.setAttribute('aria-expanded', String(willOpen));
      panel.style.maxHeight = willOpen ? panel.scrollHeight + 'px' : '0px';
    });
  });

  /* ---------------------------------------------------------
     Testimonials use the same auto-scrolling marquee as the
     trusted-by strip (see the generic marquee speed-sync
     block below) — no extra JS needed here.
  --------------------------------------------------------- */

  /* ---------------------------------------------------------
     Pricing billing toggle (monthly / yearly), language-aware
  --------------------------------------------------------- */
  const billingToggle = document.getElementById('billingToggle');
  const priceNums = document.querySelectorAll('.price-amount .num[data-price-monthly]');

  function updatePriceDisplay(){
    const period = billingToggle?.getAttribute('data-period') || 'monthly';
    const suffix = currentLang === 'en' ? '-en' : '';
    priceNums.forEach(num => {
      const value = num.getAttribute(`data-price-${period}${suffix}`) || num.getAttribute(`data-price-${period}`);
      if (value) num.textContent = value;
    });
  }

  billingToggle?.querySelectorAll('[data-period-btn]').forEach(btn => {
    btn.addEventListener('click', () => {
      const period = btn.getAttribute('data-period-btn');
      billingToggle.setAttribute('data-period', period);
      billingToggle.querySelectorAll('[data-period-btn]').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      updatePriceDisplay();
    });
  });

  /* ---------------------------------------------------------
     FAQ accordion
  --------------------------------------------------------- */
  document.querySelectorAll('.faq-item').forEach(item => {
    const question = item.querySelector('.faq-q');
    const answer = item.querySelector('.faq-a');
    if (!question || !answer) return;

    function setState(open){
      item.classList.toggle('is-open', open);
      question.setAttribute('aria-expanded', String(open));
      answer.style.maxHeight = open ? answer.scrollHeight + 'px' : '0px';
    }

    setState(item.classList.contains('is-open'));

    question.addEventListener('click', () => {
      const willOpen = !item.classList.contains('is-open');
      document.querySelectorAll('.faq-item.is-open').forEach(openItem => {
        if (openItem !== item){
          const a = openItem.querySelector('.faq-a');
          const q = openItem.querySelector('.faq-q');
          openItem.classList.remove('is-open');
          q?.setAttribute('aria-expanded', 'false');
          if (a) a.style.maxHeight = '0px';
        }
      });
      setState(willOpen);
    });
  });

  window.addEventListener('resize', () => {
    document.querySelectorAll('.faq-item.is-open .faq-a').forEach(a => {
      a.style.maxHeight = a.scrollHeight + 'px';
    });
  });

  /* ---------------------------------------------------------
     Hero visual — subtle pointer-follow tilt (responds to user action)
  --------------------------------------------------------- */
  const heroVisual = document.querySelector('.hero-visual');
  const tiltCards = document.querySelectorAll('[data-tilt]');

  if (heroVisual && tiltCards.length && !prefersReducedMotion && window.matchMedia('(pointer: fine)').matches){
    heroVisual.addEventListener('mousemove', (e) => {
      const rect = heroVisual.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      tiltCards.forEach((card, i) => {
        const depth = (i + 1) * 4;
        card.style.transform = `translate3d(${x * depth}px, ${y * depth}px, 0)`;
      });
    });
    heroVisual.addEventListener('mouseleave', () => {
      tiltCards.forEach(card => { card.style.transform = ''; });
    });
  }

  /* ---------------------------------------------------------
     Trusted-by / testimonials marquees — even speed regardless
     of item count
  --------------------------------------------------------- */
  document.querySelectorAll('.marquee').forEach(marquee => {
    const pxPerSecond = Number(marquee.getAttribute('data-speed')) || 40;
    const tracks = marquee.querySelectorAll('.marquee-track');
    const firstTrack = tracks[0];
    if (!firstTrack) return;
    const duration = Math.max(12, firstTrack.scrollWidth / pxPerSecond);
    tracks.forEach(track => { track.style.animationDuration = duration + 's'; });
  });

  /* ---------------------------------------------------------
     Newsletter form — front-end only feedback
  --------------------------------------------------------- */
  const newsletterForm = document.getElementById('newsletterForm');
  newsletterForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = newsletterForm.querySelector('button');
    const original = btn.textContent;
    btn.textContent = currentLang === 'en' ? 'Subscribed ✓' : 'ثبت شد ✓';
    newsletterForm.querySelector('input').value = '';
    setTimeout(() => { btn.textContent = original; }, 2200);
  });

  /* ===========================================================
     Bilingual support (فارسی / English)
     Persian is the default; English is opt-in and persisted.
     Every translatable element carries data-en="<english html>".
     The Persian version is auto-captured from the live DOM into
     data-fa the first time the page loads, so the markup above
     never has to duplicate the Persian text by hand.
  =========================================================== */
  const LANG_KEY = 'afarin-lang';
  let currentLang = 'fa';

  const I18N_ATTRS = [
    { attr: 'aria-label', en: 'data-en-aria-label', fa: 'data-fa-aria-label' },
    { attr: 'placeholder', en: 'data-en-placeholder', fa: 'data-fa-placeholder' }
  ];

  function captureOriginalPersian(){
    document.querySelectorAll('[data-en]').forEach(el => {
      if (!el.hasAttribute('data-fa')) el.setAttribute('data-fa', el.innerHTML);
    });
    I18N_ATTRS.forEach(({ attr, en, fa }) => {
      document.querySelectorAll(`[${en}]`).forEach(el => {
        if (!el.hasAttribute(fa)) el.setAttribute(fa, el.getAttribute(attr) || '');
      });
    });
  }

  const TITLE_FA = document.title;
  const DESC_FA = document.getElementById('pageDesc')?.getAttribute('content') || '';
  const TITLE_EN = 'Afarin — AI-powered text, image & video content generation';
  const DESC_EN = "Afarin helps your team generate professional text, image and video content in seconds, in your own brand voice.";

  function applyLanguage(lang, persist){
    currentLang = lang === 'en' ? 'en' : 'fa';
    const htmlRoot = document.getElementById('htmlRoot') || root;
    htmlRoot.setAttribute('lang', currentLang);
    htmlRoot.setAttribute('dir', currentLang === 'en' ? 'ltr' : 'rtl');

    document.querySelectorAll('[data-en]').forEach(el => {
      const value = currentLang === 'en' ? el.getAttribute('data-en') : el.getAttribute('data-fa');
      if (value !== null) el.innerHTML = value;
    });

    I18N_ATTRS.forEach(({ attr, en, fa }) => {
      document.querySelectorAll(`[${en}]`).forEach(el => {
        const value = currentLang === 'en' ? el.getAttribute(en) : el.getAttribute(fa);
        if (value !== null) el.setAttribute(attr, value);
      });
    });

    document.title = currentLang === 'en' ? TITLE_EN : TITLE_FA;
    const descEl = document.getElementById('pageDesc');
    if (descEl) descEl.setAttribute('content', currentLang === 'en' ? DESC_EN : DESC_FA);

    document.querySelectorAll('[data-lang-btn]').forEach(btn => {
      btn.classList.toggle('is-active', btn.getAttribute('data-lang-btn') === currentLang);
    });

    updatePriceDisplay();

    if (persist) localStorage.setItem(LANG_KEY, currentLang);
  }

  captureOriginalPersian();
  const savedLang = localStorage.getItem(LANG_KEY);
  if (savedLang === 'en') applyLanguage('en', false);

  document.querySelectorAll('[data-lang-btn]').forEach(btn => {
    btn.addEventListener('click', () => applyLanguage(btn.getAttribute('data-lang-btn'), true));
  });

})();
